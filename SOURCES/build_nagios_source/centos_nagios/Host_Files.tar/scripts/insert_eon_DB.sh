#!/bin/bash

LILAC_REPODIR="/home/eyesofreport/external_depot/Lilac_Depot/"
GED_REPODIR="/home/eyesofreport/external_depot/Ged_Depot/"
NAGIOSBP_REPODIR="/home/eyesofreport/external_depot/Nagios_BP_Depot/"
MYSQLUSER="eyesofreport"
PASSWDMsql="SaintThomas,2014"
Host="localhost"
SOURCE_NAME=$1

lilacdb="${SOURCE_NAME}_lilac"
geddb="${SOURCE_NAME}_ged"
nagiosbpdb="${SOURCE_NAME}_nagiosbp"

LastGedDump=$(ls -tr ${GED_REPODIR}*ged*.sql | tail -1)
LastLilacDump=$(ls -tr ${LILAC_REPODIR}*lilac*.sql | tail -1)
LastNagiosBPDump=$(ls -tr ${NAGIOSBP_REPODIR}*nagiosbp*.sql | tail -1)

MYSQL_PWD=${PASSWDMsql} mysql -u ${MYSQLUSER} -h ${Host} ${lilacdb} < $LastLilacDump
MYSQL_PWD=${PASSWDMsql} mysql -u ${MYSQLUSER} -h ${Host} ${geddb} < $LastGedDump
MYSQL_PWD=${PASSWDMsql} mysql -u ${MYSQLUSER} -h ${Host} ${nagiosbpdb} < $LastNagiosBPDump
