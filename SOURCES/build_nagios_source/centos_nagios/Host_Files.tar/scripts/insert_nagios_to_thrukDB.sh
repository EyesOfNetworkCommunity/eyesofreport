#!/bin/bash

# Michael Aubertin 10/13/2014
# Benoit Village 25/11/2014
# Insert EON MA Log into Thruk DB.
cd /srv/eyesofnetwork/thruk/script
./thruk -l > /tmp/thruk_backend
tail -n +3 /tmp/thruk_backend > /tmp/thruk_backend_2

SystemNagiosID="source_eon"
UniqLiveStatusID=$(awk '{ print $2; }' /tmp/thruk_backend_2)

rm /tmp/thruk_backend
rm /tmp/thruk_backend_2

mv -f /home/eyesofreport/external_depot/Log_Nagios_Depot/nagios-*.log /srv/eyesofnetwork/nagios/var/log/archives/

if [ ! -d /srv/eyesofnetwork/nagios/var/log/archives/ ]; then
        echo "Cannot continue. Configuration required. Please refer to SPEC book."
        exit
fi

if [ -n "`find /srv/eyesofnetwork/nagios/var/log/archives/ -type f -name nagios-*.log -exec echo {} \;`" ]; then
        echo "je trouve bien un fichier dans /srv/eyesofreport/source/${SystemNagiosID}/Archives/"
        cd /srv/eyesofnetwork/thruk/script/
        for file in `ls /srv/eyesofnetwork/nagios/var/log/archives/nagios-*.log`; do
                ./thruk -a logcacheupdate --local $file -b ${UniqLiveStatusID}
                ./thruk -a logcacheoptimize --local
        done
        cd -

         mv /srv/eyesofnetwork/nagios/var/log/archives/nagios-*.log /srv/eyesofreport/external_depot/Archives/
fi

if [ -n "`find /srv/eyesofreport/external_depot/Archives/ -type f -name nagios-*.log -exec echo {} \;`" ]; then
        for file in `ls /srv/eyesofreport/external_depot/Archives/nagios-*.log`; do
                gzip -f $file
        done
fi
